angular
  .module('root', [
    'app'
  ]);
