angular.module('common', [
    'ui.router','ngResource','ngAnimate'
]);