var APIURL = "http://localhost:3000/";

var SD_ADMIN = [{
    name: 'Home',
    link: 'app.home',
    icon: 'home'
}, {
    name: 'User',
    link: 'app.user',
    icon: 'account_box'
}, {
    name: 'Project',
    link: 'app.project',
    icon: 'group_work'
}, {
    name: 'Task',
    link: 'app.task',
    icon: 'work'
}];

var SD_USER = [{
    name: 'Task',
    link: 'app.task',
    icon: 'work'
}];
