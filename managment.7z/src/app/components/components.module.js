angular
    .module('components', ['md.data.table','ngFileUpload'])
    .config(['$stateProvider', function($stateProvider) {

    }]);
    