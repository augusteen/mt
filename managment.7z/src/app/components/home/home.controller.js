function HomeController(){

}

angular
    .module('components')
    .controller('HomeController', HomeController);
